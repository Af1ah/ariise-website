import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import authConfig from "@/auth.config";
import { authSettings, consumeRateLimit, normalizeEmail, requestIp } from "@/lib/auth-security";
import { consumeMagicLink, redeemMagicLink } from "@/lib/store";
import { verifySecret } from "@/lib/auth";
import { db } from "@/prisma/db";

// Prisma Next's generated dynamic ORM namespace does not expose model keys statically yet.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const orm = db.orm.public as any;

export const { auth, handlers, signIn, signOut } = NextAuth(() => ({
  ...authConfig,
  session: { strategy: "jwt", maxAge: authSettings().sessionMaxAge },
  providers: [
    Credentials({
      id: "password",
      name: "Email and password",
      credentials: { email: { label: "Email", type: "email" }, password: { label: "Password", type: "password" } },
      async authorize(credentials, request) {
        const email = normalizeEmail(credentials.email);
        const password = typeof credentials.password === "string" ? credentials.password : "";
        await consumeRateLimit("password", `${requestIp(request)}:${email ?? "invalid"}`);
        if (!email || !password) return null;
        const user = await orm.User.where({ email }).first();
        const dummyHash = process.env.AUTH_PASSWORD_DUMMY_HASH;
        if (!dummyHash) throw new Error("AUTH_PASSWORD_DUMMY_HASH is required");
        const passwordHash = user?.passwordHash ?? dummyHash;
        if (!(await bcrypt.compare(password, passwordHash)) || !user?.passwordHash) return null;
        return { id: user.id, email: user.email, name: user.name, sessionVersion: String(user.sessionVersion) };
      },
    }),
    Credentials({
      id: "magic-link",
      name: "WhatsApp magic link",
      credentials: { token: { label: "Token", type: "text" } },
      async authorize(credentials, request) {
        const token = typeof credentials.token === "string" ? credentials.token : "";
        await consumeRateLimit("magic-redeem", `${requestIp(request)}:${token.slice(0, 96)}`);
        const [id, secret, ...extra] = token.split(".");
        const link = id && secret && !extra.length ? await redeemMagicLink(id) : null;
        if (
          !link ||
          link.usedAt ||
          Date.parse(link.expiresAt) <= Date.now() ||
          !(await verifySecret(secret, link.secretHash))
        )
          return null;
        await consumeMagicLink(id);
        const user = await orm.User.first({ id: link.userId });
        return user
          ? { id: user.id, email: user.email, name: user.name, sessionVersion: String(user.sessionVersion) }
          : null;
      },
    }),
  ],
  callbacks: {
    jwt({ token, user }) {
      if (user) token.sessionVersion = user.sessionVersion;
      return token;
    },
    session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub ?? "";
        session.user.sessionVersion = String(token.sessionVersion ?? "");
      }
      return session;
    },
  },
}));
