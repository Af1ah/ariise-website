import { NextResponse, type NextFetchEvent, type NextRequest } from "next/server";
import { auth } from "@/auth";

const privatePaths = ["/dashboard", "/quiz", "/result"];
const securityHeaders = {
  "Content-Security-Policy": "SECURITY_CONTENT_SECURITY_POLICY",
  "Referrer-Policy": "SECURITY_REFERRER_POLICY",
  "Permissions-Policy": "SECURITY_PERMISSIONS_POLICY",
  "X-Content-Type-Options": "SECURITY_X_CONTENT_TYPE_OPTIONS",
  "X-Frame-Options": "SECURITY_X_FRAME_OPTIONS",
  "Strict-Transport-Security": "SECURITY_STRICT_TRANSPORT_SECURITY",
} as const;

function withSecurityHeaders(response: NextResponse) {
  for (const [header, variable] of Object.entries(securityHeaders)) {
    const value = process.env[variable];
    if (value) response.headers.set(header, value);
  }
  return response;
}

const authProxy = auth((request) => {
  if (
    process.env.NODE_ENV === "production" &&
    Object.values(securityHeaders).some((variable) => !process.env[variable])
  )
    return NextResponse.json({ error: "Security header configuration is incomplete" }, { status: 500 });
  const pathname = request.nextUrl.pathname;
  const protectedPath =
    (pathname.startsWith("/api/") && !pathname.startsWith("/api/auth/") && !pathname.startsWith("/api/webhooks/")) ||
    privatePaths.some((path) => pathname === path || pathname.startsWith(`${path}/`));
  if (protectedPath && !request.auth?.user?.id) {
    if (pathname.startsWith("/api/"))
      return withSecurityHeaders(NextResponse.json({ error: "Unauthorized" }, { status: 401 }));
    return withSecurityHeaders(NextResponse.redirect(new URL("/", request.url)));
  }
  return withSecurityHeaders(NextResponse.next());
});

export function proxy(request: NextRequest, event: NextFetchEvent) {
  return (authProxy as unknown as (request: NextRequest, event: NextFetchEvent) => Response | undefined)(
    request,
    event,
  );
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"] };
