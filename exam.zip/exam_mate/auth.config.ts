import type { NextAuthConfig } from "next-auth";

export default {
  providers: [],
  pages: { signIn: "/" },
  session: { strategy: "jwt" },
  trustHost: true,
} satisfies NextAuthConfig;
